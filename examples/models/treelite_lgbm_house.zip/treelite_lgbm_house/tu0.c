#include "header.h"
double predict_margin_unit0(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2085830.000000000233) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1178191.500000000233) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1992.500000000000227) ) ) {
        sum += (double)178238.3341880051594;
      } else {
        sum += (double)180351.2867818885716;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1979.500000000000227) ) ) {
        sum += (double)180264.266561932367;
      } else {
        sum += (double)182480.3731491043873;
      }
    }
  } else {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2991408.000000000466) ) ) {
        sum += (double)183518.9303624696622;
      } else {
        sum += (double)186229.9939328449254;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3881190.000000000466) ) ) {
        sum += (double)187947.5882945320918;
      } else {
        sum += (double)194851.7093015724677;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2085830.000000000233) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1178191.500000000233) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)45502.50000000000728) ) ) {
        sum += (double)-3552.393761343899314;
      } else {
        sum += (double)-1911.103707847490568;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1979.500000000000227) ) ) {
        sum += (double)-1370.161030469076877;
      } else {
        sum += (double)725.3864906769977097;
      }
    }
  } else {
    if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)65649.50000000001455) ) ) {
        sum += (double)577.6538368130335357;
      } else {
        sum += (double)3293.020533380810321;
      }
    } else {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)116023.5000000000146) ) ) {
        sum += (double)5771.664048756978445;
      } else {
        sum += (double)12134.6483197825728;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2085830.000000000233) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1206702.500000000233) ) ) {
      if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.500000000000000222) ) ) {
        sum += (double)-3418.131357985301293;
      } else {
        sum += (double)-1891.450021126693855;
      }
    } else {
      if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.500000000000000222) ) ) {
        sum += (double)-1867.502454956267911;
      } else {
        sum += (double)287.3304832282919961;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3241202.000000000466) ) ) {
      if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
        sum += (double)1878.729861033153838;
      } else {
        sum += (double)4828.611480497494995;
      }
    } else {
      if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
        sum += (double)4560.751166797992482;
      } else {
        sum += (double)9664.695152888243683;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2431104.500000000466) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1405860.500000000233) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)925290.0000000001164) ) ) {
        sum += (double)-3171.817004221075422;
      } else {
        sum += (double)-1529.890276612385833;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1993.500000000000227) ) ) {
        sum += (double)-845.2019303381753161;
      } else {
        sum += (double)1456.580591422577527;
      }
    }
  } else {
    if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
      if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-419.6616641802892218;
      } else {
        sum += (double)3607.068100412692274;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3881190.000000000466) ) ) {
        sum += (double)5578.014920691679436;
      } else {
        sum += (double)11304.79200479673636;
      }
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)68681.50000000001455) ) ) {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)45502.50000000000728) ) ) {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)408092.5000000000582) ) ) {
        sum += (double)-2965.80810314448172;
      } else {
        sum += (double)-1475.569937758742526;
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)9548.500000000001819) ) ) {
        sum += (double)190.7531410722621672;
      } else {
        sum += (double)-1422.925623880453713;
      }
    }
  } else {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2149979.000000000466) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)84248.00000000001455) ) ) {
        sum += (double)1252.818161243932764;
      } else {
        sum += (double)3376.482797210799163;
      }
    } else {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)116023.5000000000146) ) ) {
        sum += (double)6538.010273614127073;
      } else {
        sum += (double)11003.1879443780872;
      }
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
    if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.500000000000000222) ) ) {
      if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)5962567.000000000931) ) ) {
        sum += (double)-3512.220123753804273;
      } else {
        sum += (double)-1990.796440521992736;
      }
    } else {
      if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)6447600.000000000931) ) ) {
        sum += (double)-1351.247970865575098;
      } else {
        sum += (double)591.8857349642694317;
      }
    }
  } else {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)21161232.00000000373) ) ) {
      if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)101.5000000000000142) ) ) {
        sum += (double)1759.417650575145672;
      } else {
        sum += (double)4775.480282633850948;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)8.500000000000001776) ) ) {
        sum += (double)6695.244974013640785;
      } else {
        sum += (double)11082.78726976990038;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1975706.000000000233) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1150361.000000000233) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)45502.50000000000728) ) ) {
        sum += (double)-2823.904560623313046;
      } else {
        sum += (double)-1527.124204580623655;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-1333.160313204635031;
      } else {
        sum += (double)190.797208461834316;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3025249.500000000466) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)63659.00000000000728) ) ) {
        sum += (double)189.0901178354318404;
      } else {
        sum += (double)2529.010165526263336;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)91404.00000000001455) ) ) {
        sum += (double)3897.031318908463163;
      } else {
        sum += (double)7601.537011962154793;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1975706.000000000233) ) ) {
    if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)955656.0000000001164) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)3602.000000000000455) ) ) {
        sum += (double)-3157.859108661323262;
      } else {
        sum += (double)-1966.321791555410528;
      }
    } else {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)385.0000000000000568) ) ) {
        sum += (double)-1744.998486252052999;
      } else {
        sum += (double)-214.9598790712236962;
      }
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)14036.50000000000182) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)617.5000000000001137) ) ) {
        sum += (double)1046.946207985496812;
      } else {
        sum += (double)3762.145068804405582;
      }
    } else {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3657424.500000000466) ) ) {
        sum += (double)5458.140194599315691;
      } else {
        sum += (double)8924.337625441497948;
      }
    }
  }
  if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)8470.000000000001819) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1983.500000000000227) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1264120.000000000233) ) ) {
        sum += (double)-2786.388254272334962;
      } else {
        sum += (double)-1463.5942052912701;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)7.500000000000000888) ) ) {
        sum += (double)-73.63214949735777282;
      } else {
        sum += (double)2812.284999903189146;
      }
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)19438900.00000000373) ) ) {
      if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)9796.000000000001819) ) ) {
        sum += (double)3955.887031374541948;
      } else {
        sum += (double)6041.056302559868527;
      }
    } else {
      sum += (double)9167.91955761630561;
    }
  }
  if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9130.000000000001819) ) ) {
    if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1984.500000000000227) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-2316.98959179158328;
      } else {
        sum += (double)-660.4020818697741788;
      }
    } else {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)5889.000000000000909) ) ) {
        sum += (double)-57.50099686960848544;
      } else {
        sum += (double)1512.874994570669287;
      }
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)14036.50000000000182) ) ) {
      if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)959.8311055949321826;
      } else {
        sum += (double)3002.886181884123289;
      }
    } else {
      if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12854.00000000000182) ) ) {
        sum += (double)5397.184910274368121;
      } else {
        sum += (double)8363.960203781871314;
      }
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1983.500000000000227) ) ) {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)527855.0000000001164) ) ) {
        sum += (double)-2335.008669788995121;
      } else {
        sum += (double)-923.2692212915096661;
      }
    } else {
      if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.500000000000000222) ) ) {
        sum += (double)-1465.028652643962005;
      } else {
        sum += (double)805.9071981284640742;
      }
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2389380.000000000466) ) ) {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)735.410774840697627;
      } else {
        sum += (double)4213.532721754628255;
      }
    } else {
      sum += (double)7464.012216958675708;
    }
  }
  if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)10380.00000000000182) ) ) {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)17628388.00000000373) ) ) {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)3848.500000000000455) ) ) {
        sum += (double)-2567.740830131489929;
      } else {
        sum += (double)-859.538507763162329;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)26.50000000000000355) ) ) {
        sum += (double)-161.632053280685227;
      } else {
        sum += (double)1779.907747170849234;
      }
    }
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)27042352.00000000373) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)725.5000000000001137) ) ) {
        sum += (double)3993.823314206586474;
      } else {
        sum += (double)1581.146235163273104;
      }
    } else {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)14036.50000000000182) ) ) {
        sum += (double)4860.254334500031291;
      } else {
        sum += (double)8232.570246610139293;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1975706.000000000233) ) ) {
    if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1199.500000000000227) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1207182.500000000233) ) ) {
        sum += (double)-2899.884193312083426;
      } else {
        sum += (double)-1555.275176307872925;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)49166.00000000000728) ) ) {
        sum += (double)-1167.465095413984727;
      } else {
        sum += (double)112.9527990548363334;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3025249.500000000466) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)63659.00000000000728) ) ) {
        sum += (double)29.15082170240707526;
      } else {
        sum += (double)1944.293986300855067;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)96513.00000000001455) ) ) {
        sum += (double)3059.211152152029172;
      } else {
        sum += (double)5942.249452968225341;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7212.000000000000909) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1294127.500000000233) ) ) {
        sum += (double)-2659.213406522390869;
      } else {
        sum += (double)-1447.583907218640888;
      }
    } else {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
        sum += (double)-646.630284661196697;
      } else {
        sum += (double)440.7824299857002188;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)18501.00000000000364) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
        sum += (double)1675.552157169161546;
      } else {
        sum += (double)3927.706551839962685;
      }
    } else {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)116023.5000000000146) ) ) {
        sum += (double)4802.849161249223471;
      } else {
        sum += (double)7658.177876174013363;
      }
    }
  }
  if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)19331337.50000000373) ) ) {
    if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)388.5000000000000568) ) ) {
      if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)7364112.000000000931) ) ) {
        sum += (double)-2552.630034871414864;
      } else {
        sum += (double)-1423.205314342060319;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-1066.485616552712372;
      } else {
        sum += (double)411.9486083638733476;
      }
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)605.5000000000001137) ) ) {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)27210609.00000000373) ) ) {
        sum += (double)299.3673490494577436;
      } else {
        sum += (double)1829.261513785133502;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)198.0000000000000284) ) ) {
        sum += (double)1751.907167545308084;
      } else {
        sum += (double)4943.772038968712877;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1975706.000000000233) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1150361.000000000233) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1958.500000000000227) ) ) {
        sum += (double)-2268.556129747104023;
      } else {
        sum += (double)-1110.431136570237868;
      }
    } else {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1983.500000000000227) ) ) {
        sum += (double)-770.0286396168115743;
      } else {
        sum += (double)384.2340126079183165;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3025249.500000000466) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1991.500000000000227) ) ) {
        sum += (double)43.40212521967129078;
      } else {
        sum += (double)1841.820321434984635;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1991.500000000000227) ) ) {
        sum += (double)1512.599654632611191;
      } else {
        sum += (double)5142.847484615628673;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7212.000000000000909) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1264120.000000000233) ) ) {
        sum += (double)-2353.418187629953081;
      } else {
        sum += (double)-1251.615246396463817;
      }
    } else {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
        sum += (double)-569.0086876337575177;
      } else {
        sum += (double)385.3535887345851165;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15722.50000000000182) ) ) {
        sum += (double)1496.640037746671169;
      } else {
        sum += (double)3438.532931647639998;
      }
    } else {
      sum += (double)6583.753109925651188;
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1991.500000000000227) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12157.50000000000182) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1922.500000000000227) ) ) {
        sum += (double)-2338.825488882878744;
      } else {
        sum += (double)-1015.981345979909065;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)20.50000000000000355) ) ) {
        sum += (double)-409.1514821356447555;
      } else {
        sum += (double)1056.11061883437219;
      }
    }
  } else {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)1898828.000000000233) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)215.5000000000000284) ) ) {
        sum += (double)454.0775630248352854;
      } else {
        sum += (double)2639.788233160206801;
      }
    } else {
      if ( UNLIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2313646.500000000466) ) ) {
        sum += (double)3474.308124091900481;
      } else {
        sum += (double)5831.886866924308379;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7212.000000000000909) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3136.000000000000455) ) ) {
        sum += (double)-3526.917615984901659;
      } else {
        sum += (double)-1400.14129372183811;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1987.500000000000227) ) ) {
        sum += (double)-637.6662511846392363;
      } else {
        sum += (double)290.760902747142211;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15722.50000000000182) ) ) {
        sum += (double)1363.279034913101896;
      } else {
        sum += (double)3121.296139796874741;
      }
    } else {
      sum += (double)6078.034785645369084;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7212.000000000000909) ) ) {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)3455.500000000000455) ) ) {
        sum += (double)-2234.90307820826547;
      } else {
        sum += (double)-1128.576461457280629;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1974.500000000000227) ) ) {
        sum += (double)-1051.53642003939035;
      } else {
        sum += (double)142.1725935063810198;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)18501.00000000000364) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13656.00000000000182) ) ) {
        sum += (double)1325.047532778242385;
      } else {
        sum += (double)3005.274507810175237;
      }
    } else {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13014.00000000000182) ) ) {
        sum += (double)3280.514900655065503;
      } else {
        sum += (double)6947.25307113789404;
      }
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)63659.00000000000728) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1976.500000000000227) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)35589.00000000000728) ) ) {
        sum += (double)-2054.71188040275365;
      } else {
        sum += (double)-1198.531275428816116;
      }
    } else {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
        sum += (double)19.02390790335950754;
      } else {
        sum += (double)-781.5438327717897664;
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
      if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)196.5000000000000284) ) ) {
        sum += (double)-473.0193351989250914;
      } else {
        sum += (double)656.902740336458919;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)307.5000000000000568) ) ) {
        sum += (double)1469.580149373336781;
      } else {
        sum += (double)3829.165235763135115;
      }
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2831161.500000000466) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1405860.500000000233) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
        sum += (double)-2147.329516239571603;
      } else {
        sum += (double)-852.9441884013945128;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1981.500000000000227) ) ) {
        sum += (double)-327.4052137520827728;
      } else {
        sum += (double)800.3552719173126206;
      }
    }
  } else {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1991.500000000000227) ) ) {
      sum += (double)722.4382254541263819;
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)30284177.50000000373) ) ) {
        sum += (double)2587.162221149490051;
      } else {
        sum += (double)5726.230758527828584;
      }
    }
  }
  if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)10940.00000000000182) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)5541.500000000000909) ) ) {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)3471.000000000000455) ) ) {
        sum += (double)-1682.533467190319925;
      } else {
        sum += (double)-698.6891074687946457;
      }
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)20803300.00000000373) ) ) {
        sum += (double)-122.2275281793489796;
      } else {
        sum += (double)1300.567970329107766;
      }
    }
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)28952903.00000000373) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)913.0000000000001137) ) ) {
        sum += (double)2686.503076679955029;
      } else {
        sum += (double)920.2393488502617629;
      }
    } else {
      sum += (double)4823.431198361598035;
    }
  }
  if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
    if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.500000000000000222) ) ) {
      if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)5798460.000000000931) ) ) {
        sum += (double)-1674.231990447978205;
      } else {
        sum += (double)-834.2380435536821324;
      }
    } else {
      if ( UNLIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)6255535.000000000931) ) ) {
        sum += (double)-577.1516842609596551;
      } else {
        sum += (double)283.0951343338294919;
      }
    }
  } else {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)372.5000000000000568) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)9793680.000000001863) ) ) {
        sum += (double)805.5004816924123361;
      } else {
        sum += (double)2919.389511759766265;
      }
    } else {
      sum += (double)4057.332349973220516;
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1975706.000000000233) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1973.500000000000227) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1294127.500000000233) ) ) {
        sum += (double)-1732.375730786254508;
      } else {
        sum += (double)-792.3912865812611699;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1346089.000000000233) ) ) {
        sum += (double)-518.1727610114276104;
      } else {
        sum += (double)316.255322935113611;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3740006.500000000466) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1979.500000000000227) ) ) {
        sum += (double)-880.1451693877357911;
      } else {
        sum += (double)1315.791241033423603;
      }
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)95.50000000000001421) ) ) {
        sum += (double)2563.78871107195755;
      } else {
        sum += (double)4943.976673254418529;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8936.500000000001819) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3449.500000000000455) ) ) {
        sum += (double)-2490.197081361773598;
      } else {
        sum += (double)-866.7732991948380459;
      }
    } else {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)4075162.000000000466) ) ) {
        sum += (double)-79.22520141621006928;
      } else {
        sum += (double)519.0314275275476348;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15722.50000000000182) ) ) {
        sum += (double)985.2984260602906943;
      } else {
        sum += (double)2275.954634271281975;
      }
    } else {
      sum += (double)4587.450259729914251;
    }
  }
  if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)10940.00000000000182) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1782.500000000000227) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1973.500000000000227) ) ) {
        sum += (double)-1147.33705320270883;
      } else {
        sum += (double)-274.9632072199090089;
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)502.0584853781712127;
      } else {
        sum += (double)2370.770095321653116;
      }
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2223.500000000000455) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)913.0000000000001137) ) ) {
        sum += (double)2316.369492668096882;
      } else {
        sum += (double)557.0745443097315501;
      }
    } else {
      sum += (double)4455.253184679711921;
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)83398.00000000001455) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1983.500000000000227) ) ) {
      if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)102582.0000000000146) ) ) {
        sum += (double)-1500.310117401907746;
      } else {
        sum += (double)-670.6977897819225518;
      }
    } else {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1186636.000000000233) ) ) {
        sum += (double)-122.9620576958630096;
      } else {
        sum += (double)1125.35446778749656;
      }
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2389380.000000000466) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
        sum += (double)-101.7610185387932233;
      } else {
        sum += (double)1519.86797908921244;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)291.0000000000000568) ) ) {
        sum += (double)2695.111154862919648;
      } else {
        sum += (double)4202.671717441034161;
      }
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1800.500000000000227) ) ) {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1991.500000000000227) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
        sum += (double)-2068.534322654028983;
      } else {
        sum += (double)-642.3670394567376434;
      }
    } else {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1139891.000000000233) ) ) {
        sum += (double)-10.97802470703758715;
      } else {
        sum += (double)1338.742367416376055;
      }
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2004.500000000000227) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2641.500000000000455) ) ) {
        sum += (double)671.5355441350839101;
      } else {
        sum += (double)3426.754529429098056;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2232.000000000000455) ) ) {
        sum += (double)2273.464146059796803;
      } else {
        sum += (double)3938.942640167647824;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1984.500000000000227) ) ) {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1939.500000000000227) ) ) {
        sum += (double)-1846.251591115478504;
      } else {
        sum += (double)-1231.173499411808052;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)53.50000000000000711) ) ) {
        sum += (double)-639.936031901795559;
      } else {
        sum += (double)169.8860723878435124;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)592.3035739608429822;
      } else {
        sum += (double)2163.80058157015992;
      }
    } else {
      sum += (double)4152.638544407554946;
    }
  }
  if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)10940.00000000000182) ) ) {
    if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)49705.00000000000728) ) ) {
      if ( UNLIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)3634.000000000000455) ) ) {
        sum += (double)-1420.461349111534901;
      } else {
        sum += (double)-574.2764921011068964;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1986.500000000000227) ) ) {
        sum += (double)-399.6907259497808695;
      } else {
        sum += (double)571.5659552756411586;
      }
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)3068916.500000000466) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)14573.00000000000182) ) ) {
        sum += (double)1113.374435278388091;
      } else {
        sum += (double)2439.726567287222679;
      }
    } else {
      sum += (double)3998.932132418332003;
    }
  }
  if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
    if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)49705.00000000000728) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
        sum += (double)-1646.383194959701768;
      } else {
        sum += (double)-633.2289889715779054;
      }
    } else {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2005.500000000000227) ) ) {
        sum += (double)80.19005592770302826;
      } else {
        sum += (double)1263.11286180224738;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)8.500000000000001776) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2004.500000000000227) ) ) {
        sum += (double)1301.030972168800417;
      } else {
        sum += (double)2158.879418028530381;
      }
    } else {
      sum += (double)3985.176235090350019;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7212.000000000000909) ) ) {
      if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)363180.0000000000582) ) ) {
        sum += (double)-1209.667919921105295;
      } else {
        sum += (double)-511.5620221455520777;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1970.500000000000227) ) ) {
        sum += (double)-674.3264705946182858;
      } else {
        sum += (double)100.720669655968905;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)615.6493766339655167;
      } else {
        sum += (double)1645.064127020605156;
      }
    } else {
      sum += (double)3479.682514915219599;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)5274.000000000000909) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3136.000000000000455) ) ) {
        sum += (double)-2186.357137951998538;
      } else {
        sum += (double)-915.5962790688247424;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1958.500000000000227) ) ) {
        sum += (double)-830.6101692660392928;
      } else {
        sum += (double)-208.8446385754248809;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)16461.50000000000364) ) ) {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)515808.0000000000582) ) ) {
        sum += (double)239.5376920602656412;
      } else {
        sum += (double)1158.621827664437888;
      }
    } else {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20978.00000000000364) ) ) {
        sum += (double)1778.737791220138206;
      } else {
        sum += (double)3411.10653235190739;
      }
    }
  }
  if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)602.5000000000001137) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)16.50000000000000355) ) ) {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-1295.193346488560337;
      } else {
        sum += (double)-489.2770428168242915;
      }
    } else {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)385.0000000000000568) ) ) {
        sum += (double)-670.4901237644547791;
      } else {
        sum += (double)298.1561155130966654;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)25.50000000000000355) ) ) {
        sum += (double)-296.7559619457114763;
      } else {
        sum += (double)991.9198865880626954;
      }
    } else {
      sum += (double)3249.686082160090791;
    }
  }
  if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
    if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)49705.00000000000728) ) ) {
      if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)96.50000000000001421) ) ) {
        sum += (double)-859.6752939037411352;
      } else {
        sum += (double)-253.7751604453563345;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)26.50000000000000355) ) ) {
        sum += (double)-257.4468629973662246;
      } else {
        sum += (double)510.0307438333569507;
      }
    }
  } else {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)11845.00000000000182) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)10465.00000000000182) ) ) {
        sum += (double)1231.806837523406784;
      } else {
        sum += (double)2040.654628493288783;
      }
    } else {
      sum += (double)3058.68720286163807;
    }
  }
  if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)26.50000000000000355) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
        sum += (double)-1183.072983262176422;
      } else {
        sum += (double)-406.9507625094982473;
      }
    } else {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)117.0807764211786832;
      } else {
        sum += (double)1986.077189433545072;
      }
    }
  } else {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)11845.00000000000182) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)11754563.00000000186) ) ) {
        sum += (double)1982.443241105912193;
      } else {
        sum += (double)1074.656423450094735;
      }
    } else {
      sum += (double)2892.290744124873072;
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2831161.500000000466) ) ) {
    if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1104530.000000000233) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1965.500000000000227) ) ) {
        sum += (double)-929.7238085143051194;
      } else {
        sum += (double)-337.0677274368326835;
      }
    } else {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1999.500000000000227) ) ) {
        sum += (double)-103.5673607029223433;
      } else {
        sum += (double)472.0458828349943587;
      }
    }
  } else {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1979.500000000000227) ) ) {
      sum += (double)-380.9425296331336881;
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)30284177.50000000373) ) ) {
        sum += (double)1127.057053169678966;
      } else {
        sum += (double)2966.62278202815196;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)12113.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)8936.500000000001819) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3136.000000000000455) ) ) {
        sum += (double)-1880.415272536698922;
      } else {
        sum += (double)-511.5205764968226845;
      }
    } else {
      if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)69.00000000000001421) ) ) {
        sum += (double)-161.5362045166600069;
      } else {
        sum += (double)314.0556483041276579;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15722.50000000000182) ) ) {
        sum += (double)538.1855055375591519;
      } else {
        sum += (double)1359.669591572383524;
      }
    } else {
      sum += (double)2758.731189766066564;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1979.500000000000227) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)1538.000000000000227) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1969.500000000000227) ) ) {
        sum += (double)-1014.990775279581612;
      } else {
        sum += (double)-509.8189382414961415;
      }
    } else {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-948.8828051154534933;
      } else {
        sum += (double)-56.37406730052179427;
      }
    }
  } else {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2389380.000000000466) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)296.2919232350873244;
      } else {
        sum += (double)1587.865619452207966;
      }
    } else {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)790.5000000000001137) ) ) {
        sum += (double)1595.063644692950902;
      } else {
        sum += (double)2899.604363078834012;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)5274.000000000000909) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3136.000000000000455) ) ) {
        sum += (double)-1736.400230253211248;
      } else {
        sum += (double)-700.6966702303751617;
      }
    } else {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-429.1765313777457322;
      } else {
        sum += (double)-44.29745715937831818;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)16601.00000000000364) ) ) {
      if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-88.91611880666798129;
      } else {
        sum += (double)651.9851222282317167;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
        sum += (double)1231.026101576256906;
      } else {
        sum += (double)2635.264079654400575;
      }
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)83398.00000000001455) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1973.500000000000227) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1294127.500000000233) ) ) {
        sum += (double)-964.7813895147487528;
      } else {
        sum += (double)-359.0387591764630315;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1666740.500000000233) ) ) {
        sum += (double)-172.6001610750817008;
      } else {
        sum += (double)386.7379996341143737;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)104.9117297979040586;
      } else {
        sum += (double)1100.607088685492272;
      }
    } else {
      sum += (double)2748.584974726089968;
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)63252.50000000000728) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1976.500000000000227) ) ) {
      if ( UNLIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)78099.00000000001455) ) ) {
        sum += (double)-1015.45287979652403;
      } else {
        sum += (double)-387.9089144359656416;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)44528.50000000000728) ) ) {
        sum += (double)-303.0143069477884978;
      } else {
        sum += (double)119.8319681973578099;
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)109.0000000000000142) ) ) {
        sum += (double)632.4309261911726026;
      } else {
        sum += (double)-341.7646185544195987;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3881190.000000000466) ) ) {
        sum += (double)633.5787310042246645;
      } else {
        sum += (double)2175.21037619702247;
      }
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1979.500000000000227) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)1538.000000000000227) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)619180.0000000001164) ) ) {
        sum += (double)-1050.982657485679283;
      } else {
        sum += (double)-545.1833699565557936;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1925.500000000000227) ) ) {
        sum += (double)-950.0523243624380711;
      } else {
        sum += (double)-45.24002472414822051;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)6024.000000000000909) ) ) {
        sum += (double)179.6222777968790751;
      } else {
        sum += (double)1083.783122007768043;
      }
    } else {
      sum += (double)2728.559893531563375;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10013.50000000000182) ) ) {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)4465.000000000000909) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)3136.000000000000455) ) ) {
        sum += (double)-1511.894773877776515;
      } else {
        sum += (double)-707.4914563281135997;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)523.0000000000001137) ) ) {
        sum += (double)-134.8986724600950993;
      } else {
        sum += (double)-520.6187541367384028;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)16601.00000000000364) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)489.0000000000000568) ) ) {
        sum += (double)727.4329999676638181;
      } else {
        sum += (double)30.27310505957686715;
      }
    } else {
      if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
        sum += (double)1122.191304290904782;
      } else {
        sum += (double)2414.305469162649842;
      }
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2005.500000000000227) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)519.5000000000001137) ) ) {
        sum += (double)-333.349811688895727;
      } else {
        sum += (double)-778.3631770973141784;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)87.50000000000001421) ) ) {
        sum += (double)42.01634054567180243;
      } else {
        sum += (double)665.4015295601865319;
      }
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)16.50000000000000355) ) ) {
        sum += (double)-27.88031660000017098;
      } else {
        sum += (double)513.3001672483358107;
      }
    } else {
      sum += (double)2570.933390371621954;
    }
  }
  if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2831161.500000000466) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)530554.5000000001164) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)857402.0000000001164) ) ) {
        sum += (double)-639.66312020262842;
      } else {
        sum += (double)-203.4762075042341962;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)53.50000000000000711) ) ) {
        sum += (double)25.14963301697878961;
      } else {
        sum += (double)488.2006119359475633;
      }
    }
  } else {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)26.50000000000000355) ) ) {
      sum += (double)-571.0392124577837194;
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)356.5000000000000568) ) ) {
        sum += (double)2646.308734826787713;
      } else {
        sum += (double)932.7952258575669475;
      }
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1800.500000000000227) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)527855.0000000001164) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1133.000000000000227) ) ) {
        sum += (double)-681.7750686536522835;
      } else {
        sum += (double)-241.6285863306495969;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1640.500000000000227) ) ) {
        sum += (double)-28.4974933809688018;
      } else {
        sum += (double)570.4106378946707991;
      }
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2682.000000000000455) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)331.0003123145622794;
      } else {
        sum += (double)1549.78192720878792;
      }
    } else {
      sum += (double)2032.677878696002836;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)5274.000000000000909) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)589327.0000000001164) ) ) {
        sum += (double)-1077.551755988564082;
      } else {
        sum += (double)-446.2723664055940276;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2400325.000000000466) ) ) {
        sum += (double)-128.423982257769012;
      } else {
        sum += (double)-1032.903297445104272;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)489.0000000000000568) ) ) {
        sum += (double)870.1468348639162969;
      } else {
        sum += (double)118.7391102316530009;
      }
    } else {
      sum += (double)1929.984489072377073;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)-1211.779474235058842;
    } else {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2005.500000000000227) ) ) {
        sum += (double)-382.2569760229939106;
      } else {
        sum += (double)330.3880386509857203;
      }
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1899.500000000000227) ) ) {
        sum += (double)79.77822127083925352;
      } else {
        sum += (double)690.7615184604901515;
      }
    } else {
      sum += (double)2306.585504630256764;
    }
  }
  return sum;
}
