#include "header.h"
double predict_margin_unit1(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)872.5000000000001137) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2005.500000000000227) ) ) {
        sum += (double)-744.032377335510887;
      } else {
        sum += (double)223.7781292926260619;
      }
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)19062127.00000000373) ) ) {
        sum += (double)-143.2270148767589717;
      } else {
        sum += (double)-735.0904733412456835;
      }
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)45679150.00000000745) ) ) {
        sum += (double)190.372619639530626;
      } else {
        sum += (double)1362.33826001066609;
      }
    } else {
      sum += (double)2181.104303004422945;
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-1715.938505769829362;
      } else {
        sum += (double)-817.3390966234858297;
      }
    } else {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
        sum += (double)-64.98948390255230834;
      } else {
        sum += (double)773.1128190994528495;
      }
    }
  } else {
    sum += (double)1612.022398241411565;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-1622.589291682476187;
      } else {
        sum += (double)-772.874821627374331;
      }
    } else {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)527855.0000000001164) ) ) {
        sum += (double)-203.7179801328302915;
      } else {
        sum += (double)229.2706860334887438;
      }
    }
  } else {
    sum += (double)1524.326337407633218;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1991.500000000000227) ) ) {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1954.500000000000227) ) ) {
        sum += (double)-1063.377840364396434;
      } else {
        sum += (double)-626.6449703798258497;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2400325.000000000466) ) ) {
        sum += (double)-187.5110246623150374;
      } else {
        sum += (double)-677.1251234282151472;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2806591.000000000466) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1470748.000000000233) ) ) {
        sum += (double)-87.33221762275702815;
      } else {
        sum += (double)255.5903237284726117;
      }
    } else {
      if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)4.500000000000000888) ) ) {
        sum += (double)1983.068150479171209;
      } else {
        sum += (double)685.6839304106796362;
      }
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-1504.813771216144914;
      } else {
        sum += (double)-711.7703247458772466;
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21494.00000000000364) ) ) {
        sum += (double)-35.67480427718586355;
      } else {
        sum += (double)1298.54700269889122;
      }
    }
  } else {
    sum += (double)1413.425233098622584;
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15722.50000000000182) ) ) {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)619180.0000000001164) ) ) {
        sum += (double)-649.9308925832872319;
      } else {
        sum += (double)-213.9113691315242818;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2984116.000000000466) ) ) {
        sum += (double)279.8890999519155116;
      } else {
        sum += (double)-801.1246035676588235;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20978.00000000000364) ) ) {
      if ( UNLIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)112.5000000000000142) ) ) {
        sum += (double)119.4913583393129528;
      } else {
        sum += (double)920.9408129624415551;
      }
    } else {
      sum += (double)1653.812031400495243;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1979.500000000000227) ) ) {
    if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1542738.000000000233) ) ) {
        sum += (double)-570.9946769512923765;
      } else {
        sum += (double)-1793.338034157025959;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
        sum += (double)-817.0289130116957494;
      } else {
        sum += (double)-78.23534450980983479;
      }
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2348.500000000000455) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)803.5000000000001137) ) ) {
        sum += (double)348.957589824557374;
      } else {
        sum += (double)-122.5021447835035957;
      }
    } else {
      if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)2251.775927091237918;
      } else {
        sum += (double)709.9568431605015348;
      }
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2004.500000000000227) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)17281.50000000000364) ) ) {
        sum += (double)-141.9252288240652717;
      } else {
        sum += (double)-1248.283848337613108;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)307.5000000000000568) ) ) {
        sum += (double)255.1869623711425845;
      } else {
        sum += (double)1354.741228471632667;
      }
    }
  } else {
    sum += (double)1676.265886499658791;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)527855.0000000001164) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
        sum += (double)-713.0459190841219197;
      } else {
        sum += (double)-172.0992161239311145;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)201.5000000000000284) ) ) {
        sum += (double)211.5220520850436685;
      } else {
        sum += (double)-775.9599622200340718;
      }
    }
  } else {
    sum += (double)1258.392437799385107;
  }
  if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)38299184.00000000745) ) ) {
    if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)251.0000000000000284) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1382.500000000000227) ) ) {
        sum += (double)-74.14554323736308561;
      } else {
        sum += (double)-844.2577741186765934;
      }
    } else {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)804.0000000000001137) ) ) {
        sum += (double)169.2067645532794984;
      } else {
        sum += (double)973.5184103088049596;
      }
    }
  } else {
    sum += (double)1543.579677389653853;
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1954.500000000000227) ) ) {
        sum += (double)-901.1155127220064287;
      } else {
        sum += (double)-510.1794580459950339;
      }
    } else {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)8.500000000000001776) ) ) {
        sum += (double)-148.1934210528416713;
      } else {
        sum += (double)-807.2994312719641812;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)4102237.000000000466) ) ) {
        sum += (double)-68.66286095058234196;
      } else {
        sum += (double)405.6991499349035735;
      }
    } else {
      sum += (double)1571.025811640789698;
    }
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1977.500000000000227) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1920.500000000000227) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)1220.000000000000227) ) ) {
        sum += (double)-438.6810929949905358;
      } else {
        sum += (double)-1302.558855424451849;
      }
    } else {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1993.500000000000227) ) ) {
        sum += (double)-235.1840692932209436;
      } else {
        sum += (double)179.5883802494477379;
      }
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)5982.000000000000909) ) ) {
        sum += (double)89.80485186633930539;
      } else {
        sum += (double)606.210641961570559;
      }
    } else {
      sum += (double)1624.820640009812223;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)530554.5000000001164) ) ) {
      if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)54.50000000000000711) ) ) {
        sum += (double)-401.5676679222771099;
      } else {
        sum += (double)-11.32389354699036232;
      }
    } else {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13656.00000000000182) ) ) {
        sum += (double)78.7962595793451186;
      } else {
        sum += (double)822.5524461930956477;
      }
    }
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)22240035.00000000373) ) ) {
      if ( UNLIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
        sum += (double)44.36693571026419392;
      } else {
        sum += (double)666.4272055240386408;
      }
    } else {
      sum += (double)1801.434486214630851;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1941.500000000000227) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1427819.500000000233) ) ) {
        sum += (double)-572.7418756314519896;
      } else {
        sum += (double)-1082.184992161882064;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2509185.000000000466) ) ) {
        sum += (double)-93.83815336065282509;
      } else {
        sum += (double)-992.0674781052795197;
      }
    }
  } else {
    if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1979.500000000000227) ) ) {
        sum += (double)-103.5669990086825578;
      } else {
        sum += (double)345.9650584930485024;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2654654.000000000466) ) ) {
        sum += (double)284.2926187923654311;
      } else {
        sum += (double)1744.438221023247934;
      }
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2004.500000000000227) ) ) {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-615.8576205961583128;
      } else {
        sum += (double)-81.36069504786388507;
      }
    } else {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)524.0000000000001137) ) ) {
        sum += (double)-98.4221667005068781;
      } else {
        sum += (double)617.686607630427261;
      }
    }
  } else {
    sum += (double)1408.762383527281372;
  }
  if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)37028591.00000000745) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-599.7511713315839188;
      } else {
        sum += (double)-83.02395950382857848;
      }
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)26201700.00000000373) ) ) {
        sum += (double)146.3384241049018044;
      } else {
        sum += (double)990.2430125165793697;
      }
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1993.500000000000227) ) ) {
      sum += (double)80.21119322955244968;
    } else {
      sum += (double)1586.906776497846522;
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-1256.883754601731425;
      } else {
        sum += (double)-563.0886727106424132;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1221.500000000000227) ) ) {
        sum += (double)-240.3461335082680819;
      } else {
        sum += (double)128.1421700141317501;
      }
    }
  } else {
    sum += (double)1046.230857225625869;
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2509185.000000000466) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)1207182.500000000233) ) ) {
        sum += (double)-369.9575089350613553;
      } else {
        sum += (double)-77.16312502637674697;
      }
    } else {
      sum += (double)-996.7384547744593419;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4026060.000000000466) ) ) {
        sum += (double)189.0893465890351308;
      } else {
        sum += (double)-611.1391696922411256;
      }
    } else {
      sum += (double)1148.913735327456607;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)277.5000000000000568) ) ) {
        sum += (double)-402.8549380788547296;
      } else {
        sum += (double)-959.4186912771147036;
      }
    } else {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)589327.0000000001164) ) ) {
        sum += (double)-500.1890630518713579;
      } else {
        sum += (double)-104.3751632690672579;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20863.00000000000364) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)484.5000000000000568) ) ) {
        sum += (double)538.4893918929528809;
      } else {
        sum += (double)-30.19739408363799882;
      }
    } else {
      sum += (double)1089.776623976935525;
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-398.6486060542064251;
      } else {
        sum += (double)-865.602266990912085;
      }
    } else {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21143.00000000000364) ) ) {
        sum += (double)-20.10926739937283259;
      } else {
        sum += (double)810.8187378743799627;
      }
    }
  } else {
    sum += (double)970.7414698569683651;
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2006.500000000000227) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1920.500000000000227) ) ) {
        sum += (double)-487.2509350734115401;
      } else {
        sum += (double)-40.62462996935729365;
      }
    } else {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1251380.000000000233) ) ) {
        sum += (double)204.4624623172233271;
      } else {
        sum += (double)1337.439819944403553;
      }
    }
  } else {
    sum += (double)1203.348482507306699;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2682.000000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-1007.204413661345598;
      } else {
        sum += (double)-406.1357669351021968;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1221.500000000000227) ) ) {
        sum += (double)-206.1042183493045172;
      } else {
        sum += (double)112.6821927911729659;
      }
    }
  } else {
    sum += (double)1140.380404666676441;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1976.500000000000227) ) ) {
    if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1519673.000000000233) ) ) {
        sum += (double)-421.1603073853954129;
      } else {
        sum += (double)-1493.868322708962751;
      }
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
        sum += (double)-656.4444088601806016;
      } else {
        sum += (double)-22.89732360034568615;
      }
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)482.0000000000000568) ) ) {
        sum += (double)341.2583253442015234;
      } else {
        sum += (double)-69.45063885794569103;
      }
    } else {
      sum += (double)1072.286448218644637;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2682.000000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
        sum += (double)-932.3292504384988888;
      } else {
        sum += (double)-375.4894171073960933;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1221.500000000000227) ) ) {
        sum += (double)-193.6369644214022401;
      } else {
        sum += (double)105.3607707821264228;
      }
    }
  } else {
    sum += (double)1063.389423017946683;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2007.500000000000227) ) ) {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-623.4352647282587441;
      } else {
        sum += (double)-69.61870612058262964;
      }
    } else {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)38256960.00000000745) ) ) {
        sum += (double)44.91231279704036439;
      } else {
        sum += (double)1159.183772929751058;
      }
    }
  } else {
    sum += (double)855.695255323476772;
  }
  if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)38299184.00000000745) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2006.500000000000227) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15529228.50000000186) ) ) {
        sum += (double)-13.27649597360414191;
      } else {
        sum += (double)-358.1789745149617943;
      }
    } else {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)7582724.000000000931) ) ) {
        sum += (double)177.1667880777027619;
      } else {
        sum += (double)1252.720728905869237;
      }
    }
  } else {
    sum += (double)1020.180558779648322;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1533056.000000000233) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1959.500000000000227) ) ) {
        sum += (double)-504.6054391592131196;
      } else {
        sum += (double)-45.9951128594821057;
      }
    } else {
      sum += (double)-1709.889347009079302;
    }
  } else {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)10465.00000000000182) ) ) {
      if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)1538.000000000000227) ) ) {
        sum += (double)-125.1119607932120488;
      } else {
        sum += (double)145.923448337384059;
      }
    } else {
      sum += (double)1105.5651340110403;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2682.000000000000455) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)4.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)277.5000000000000568) ) ) {
        sum += (double)-215.1245625061108342;
      } else {
        sum += (double)-758.269485587600343;
      }
    } else {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1235.500000000000227) ) ) {
        sum += (double)-172.3019823437192315;
      } else {
        sum += (double)100.801390870527257;
      }
    }
  } else {
    sum += (double)967.7156124208796655;
  }
  if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)37028591.00000000745) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)530554.5000000001164) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)18076351.50000000373) ) ) {
        sum += (double)-109.5010895506886186;
      } else {
        sum += (double)-597.3052419082761162;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)54.50000000000000711) ) ) {
        sum += (double)-14.5031292217498855;
      } else {
        sum += (double)317.2032859745116866;
      }
    }
  } else {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      sum += (double)145.3337775322478365;
    } else {
      sum += (double)1046.806163771880165;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2375640.500000000466) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)5274.000000000000909) ) ) {
        sum += (double)-276.3558151238015057;
      } else {
        sum += (double)-33.0153104380734419;
      }
    } else {
      sum += (double)-724.7548293932939032;
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2149547.000000000466) ) ) {
        sum += (double)92.49568246471073962;
      } else {
        sum += (double)-1325.411465463050035;
      }
    } else {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20600.00000000000364) ) ) {
        sum += (double)266.5684954615946367;
      } else {
        sum += (double)1359.235005325874454;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1934160.500000000233) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9219.000000000001819) ) ) {
        sum += (double)-130.7132194422914608;
      } else {
        sum += (double)263.1976640328909411;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1996.500000000000227) ) ) {
        sum += (double)-539.5732586146575613;
      } else {
        sum += (double)-56.59381178950690838;
      }
    }
  } else {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1918.500000000000227) ) ) {
      sum += (double)-916.5907927946720974;
    } else {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1952.500000000000227) ) ) {
        sum += (double)1320.0336678725198;
      } else {
        sum += (double)246.3186331815088579;
      }
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)241.5000000000000284) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)23678519.00000000373) ) ) {
        sum += (double)-52.21671178551200398;
      } else {
        sum += (double)951.6264628372950938;
      }
    } else {
      sum += (double)-1098.410033079552477;
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1992.500000000000227) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1934160.500000000233) ) ) {
        sum += (double)287.7693108838921603;
      } else {
        sum += (double)492.0437801510484519;
      }
    } else {
      sum += (double)1462.728367925278235;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)17635.50000000000364) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-175.3506715818357122;
      } else {
        sum += (double)145.0525713855014089;
      }
    } else {
      sum += (double)-986.0194763655290444;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12235.00000000000182) ) ) {
        sum += (double)251.3779238820648629;
      } else {
        sum += (double)-344.5020774584444325;
      }
    } else {
      sum += (double)1441.574531502858918;
    }
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)45502.50000000000728) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)7.500000000000000888) ) ) {
        sum += (double)-211.6226341019735173;
      } else {
        sum += (double)312.1594018402905135;
      }
    } else {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15529228.50000000186) ) ) {
        sum += (double)163.0491477640734672;
      } else {
        sum += (double)-221.7760993749916736;
      }
    }
  } else {
    sum += (double)948.62753090010915;
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2004.500000000000227) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3528661.500000000466) ) ) {
        sum += (double)-66.01229602584697886;
      } else {
        sum += (double)-1136.324882438821078;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)44528.50000000000728) ) ) {
        sum += (double)-228.8949913173912876;
      } else {
        sum += (double)391.0004875728615161;
      }
    }
  } else {
    sum += (double)897.0209941466544024;
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15662.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3058747.000000000466) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
        sum += (double)-142.3613452801583321;
      } else {
        sum += (double)131.8721111624472826;
      }
    } else {
      sum += (double)-1099.88802621062564;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)856.5000000000001137) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)790.5000000000001137) ) ) {
        sum += (double)300.2136151545804523;
      } else {
        sum += (double)1774.677482485484688;
      }
    } else {
      sum += (double)-295.8441847369164179;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-159.4970943120506774;
      } else {
        sum += (double)118.227799212701953;
      }
    } else {
      sum += (double)-945.7366825777620534;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1967.500000000000227) ) ) {
        sum += (double)417.9012180618652224;
      } else {
        sum += (double)-543.1284423829711159;
      }
    } else {
      sum += (double)1335.393119512314797;
    }
  }
  if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)193.5000000000000284) ) ) {
        sum += (double)-96.58189429895169553;
      } else {
        sum += (double)-1130.026136432083376;
      }
    } else {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9130.000000000001819) ) ) {
        sum += (double)92.648008682047859;
      } else {
        sum += (double)1223.538398122542503;
      }
    }
  } else {
    sum += (double)821.9221314800566915;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
        sum += (double)67.98678116575027275;
      } else {
        sum += (double)967.3500760783163059;
      }
    } else {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)16280571.00000000186) ) ) {
        sum += (double)-80.13534910628935393;
      } else {
        sum += (double)-427.6149160120672263;
      }
    }
  } else {
    sum += (double)866.1772314864707596;
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
      sum += (double)-686.9761059442244004;
    } else {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)25367895.00000000373) ) ) {
        sum += (double)10.62301045300609914;
      } else {
        sum += (double)-532.0162027590289426;
      }
    }
  } else {
    sum += (double)814.3250986941035308;
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
    if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
      if ( UNLIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)184.9037017136343479;
      } else {
        sum += (double)-84.68927916564246061;
      }
    } else {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-711.2070794970958332;
      } else {
        sum += (double)-186.2130398509515317;
      }
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)107.5000000000000142) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)20978.00000000000364) ) ) {
        sum += (double)138.3844445772187441;
      } else {
        sum += (double)1569.531335769405814;
      }
    } else {
      sum += (double)-616.0388029473224378;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)13475.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2364211.000000000466) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)7447.000000000000909) ) ) {
        sum += (double)-147.6723936147195388;
      } else {
        sum += (double)88.63202836441401189;
      }
    } else {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)11497.50000000000182) ) ) {
        sum += (double)-681.9336889072203576;
      } else {
        sum += (double)-67.88824035422510406;
      }
    }
  } else {
    if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)20.50000000000000355) ) ) {
      sum += (double)-340.127387615950056;
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)185.5000000000000284) ) ) {
        sum += (double)541.0877500222724166;
      } else {
        sum += (double)-377.175651400085485;
      }
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1920.500000000000227) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)230956.0000000000291) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)40807.50000000000728) ) ) {
        sum += (double)-476.2478671089556315;
      } else {
        sum += (double)3.705263532242061952;
      }
    } else {
      sum += (double)-1096.617326709167628;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)229.5000000000000284) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
        sum += (double)23.78555750809110947;
      } else {
        sum += (double)1658.20470903046521;
      }
    } else {
      sum += (double)-900.7298533434823185;
    }
  }
  if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)241.5000000000000284) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)25476820.00000000373) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)164.0000000000000284) ) ) {
        sum += (double)-29.50185331438284564;
      } else {
        sum += (double)484.8668720703565782;
      }
    } else {
      sum += (double)1171.836483265235756;
    }
  } else {
    sum += (double)-686.3482974469160354;
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( UNLIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)1538.000000000000227) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)112101.0000000000146) ) ) {
        sum += (double)-155.9135522055771048;
      } else {
        sum += (double)298.8159963443365541;
      }
    } else {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)119716.0000000000146) ) ) {
        sum += (double)106.9035356800417844;
      } else {
        sum += (double)-779.3124831181776244;
      }
    }
  } else {
    sum += (double)657.6288869698007602;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1533056.000000000233) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)504.5000000000000568) ) ) {
        sum += (double)-352.8701396332914442;
      } else {
        sum += (double)125.9719131769571021;
      }
    } else {
      sum += (double)-1558.895177521862024;
    }
  } else {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)36325957.50000000745) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1912.500000000000227) ) ) {
        sum += (double)-849.1698687396636842;
      } else {
        sum += (double)58.20810688221473583;
      }
    } else {
      sum += (double)1382.477428465921776;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)11334.00000000000182) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)14313.00000000000182) ) ) {
        sum += (double)-67.29913279387912439;
      } else {
        sum += (double)344.9108906130822447;
      }
    } else {
      sum += (double)-1097.125935845042022;
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15094.50000000000182) ) ) {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1229618.000000000233) ) ) {
        sum += (double)316.9021266471262379;
      } else {
        sum += (double)-131.8476993961498351;
      }
    } else {
      sum += (double)1414.213421742055971;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)241.5000000000000284) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
        sum += (double)-48.92992668965856495;
      } else {
        sum += (double)886.6093042894846121;
      }
    } else {
      sum += (double)-884.8010298836096581;
    }
  } else {
    if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1986.500000000000227) ) ) {
      sum += (double)178.5569609938426652;
    } else {
      sum += (double)1051.282269049034539;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2682.000000000000455) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)-31.46455847132155981;
      } else {
        sum += (double)544.927040212993802;
      }
    } else {
      sum += (double)1514.40075662910067;
    }
  } else {
    sum += (double)-729.2994388844635978;
  }
  if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)2007.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)-61.92421040857256997;
      } else {
        sum += (double)237.2609858555673554;
      }
    } else {
      sum += (double)-962.5806695462136986;
    }
  } else {
    sum += (double)693.6983510666443635;
  }
  return sum;
}
