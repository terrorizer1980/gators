#include "header.h"
double predict_margin_unit2(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3528661.500000000466) ) ) {
        sum += (double)6.88260749171185271;
      } else {
        sum += (double)-670.0234467135221621;
      }
    } else {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)843474.0000000001164) ) ) {
        sum += (double)544.1696720599886703;
      } else {
        sum += (double)1504.867827958050839;
      }
    }
  } else {
    sum += (double)-681.5088134512790248;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)54.50000000000000711) ) ) {
        sum += (double)-93.42834673515078237;
      } else {
        sum += (double)103.5579787128939557;
      }
    } else {
      sum += (double)-663.3987835395388402;
    }
  } else {
    sum += (double)845.1564861628176004;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2304180.000000000466) ) ) {
        sum += (double)26.12464418076532269;
      } else {
        sum += (double)770.5402258918113603;
      }
    } else {
      sum += (double)906.1369764635611546;
    }
  } else {
    if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)626268.5000000001164) ) ) {
      sum += (double)-551.5764450206592073;
    } else {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)1126404.000000000233) ) ) {
        sum += (double)-46.63431560428384159;
      } else {
        sum += (double)-411.5361467674285905;
      }
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
      if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)313.5000000000000568) ) ) {
        sum += (double)21.17766990102918001;
      } else {
        sum += (double)675.5184452864717741;
      }
    } else {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1958.500000000000227) ) ) {
        sum += (double)-524.1554972088283648;
      } else {
        sum += (double)-89.52532041115392758;
      }
    }
  } else {
    sum += (double)794.5733074692645914;
  }
  if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)530554.5000000001164) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)168.5000000000000284) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)861.0000000000001137) ) ) {
        sum += (double)-95.91435384891879323;
      } else {
        sum += (double)-676.5513453828767751;
      }
    } else {
      sum += (double)517.8700206456596788;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)201.5000000000000284) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
        sum += (double)88.78854820946108362;
      } else {
        sum += (double)1161.496491146227527;
      }
    } else {
      sum += (double)-733.4563421466124282;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)950.0000000000001137) ) ) {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)4465.000000000000909) ) ) {
        sum += (double)-270.0738333916605143;
      } else {
        sum += (double)-5.406624133379114738;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)96.00000000000001421) ) ) {
        sum += (double)-439.094942297232592;
      } else {
        sum += (double)25.86706989215523578;
      }
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)167.5000000000000284) ) ) {
      sum += (double)722.5064325576746569;
    } else {
      if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)2.500000000000000444) ) ) {
        sum += (double)826.2972358242257087;
      } else {
        sum += (double)28.93647827760958435;
      }
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1920.500000000000227) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)230956.0000000000291) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1924.500000000000227) ) ) {
        sum += (double)-339.0494595595119449;
      } else {
        sum += (double)10.08556662353120892;
      }
    } else {
      sum += (double)-993.7882609714587261;
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
      if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
        sum += (double)91.54776015959227209;
      } else {
        sum += (double)-122.7776080736921358;
      }
    } else {
      sum += (double)742.4957671375899508;
    }
  }
  if ( UNLIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2509185.000000000466) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)35855.00000000000728) ) ) {
        sum += (double)-233.5096868167671857;
      } else {
        sum += (double)-20.52234143526368371;
      }
    } else {
      sum += (double)-765.8981789787642356;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)131346.0000000000291) ) ) {
        sum += (double)49.20694213853906263;
      } else {
        sum += (double)-634.992463361963587;
      }
    } else {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9187.500000000001819) ) ) {
        sum += (double)248.7133922409771571;
      } else {
        sum += (double)1162.325265724782867;
      }
    }
  }
  if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1992.500000000000227) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9621.000000000001819) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1965.500000000000227) ) ) {
        sum += (double)-154.507281404320139;
      } else {
        sum += (double)40.83169080197388467;
      }
    } else {
      sum += (double)-714.9994605201628701;
    }
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)817.0000000000001137) ) ) {
        sum += (double)160.5747122424865552;
      } else {
        sum += (double)947.6097919101310936;
      }
    } else {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)864.5000000000001137) ) ) {
        sum += (double)49.63563437032827608;
      } else {
        sum += (double)-823.8495708850700794;
      }
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)16720042.00000000186) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)646.5000000000001137) ) ) {
        sum += (double)-50.32026174352565562;
      } else {
        sum += (double)-510.6604790449188158;
      }
    } else {
      sum += (double)-1197.735136340038707;
    }
  } else {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)36325957.50000000745) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)-21.40423160917401191;
      } else {
        sum += (double)249.0143795552816925;
      }
    } else {
      sum += (double)1191.898267875160855;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
      if ( UNLIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)262418.0000000000582) ) ) {
        sum += (double)-113.3611327010809617;
      } else {
        sum += (double)52.99731693178176783;
      }
    } else {
      sum += (double)1201.791622476621114;
    }
  } else {
    sum += (double)-618.4768086679681574;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1533056.000000000233) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1767.500000000000227) ) ) {
        sum += (double)-260.3064954104215758;
      } else {
        sum += (double)267.039807513441076;
      }
    } else {
      sum += (double)-1367.372934130921976;
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)23678519.00000000373) ) ) {
      if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)7784925.500000000931) ) ) {
        sum += (double)-154.0135289002037382;
      } else {
        sum += (double)73.92537285747667397;
      }
    } else {
      sum += (double)1225.703493205292034;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3930850.000000000466) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-125.0862382029834521;
      } else {
        sum += (double)96.42109313456822406;
      }
    } else {
      sum += (double)-649.8800842652871097;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)568.0000000000001137) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)72807.00000000001455) ) ) {
        sum += (double)108.4263613809564504;
      } else {
        sum += (double)491.1597699049968355;
      }
    } else {
      sum += (double)1278.934113755735552;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)193.5000000000000284) ) ) {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)19.00000000000000355) ) ) {
        sum += (double)-259.554618911179432;
      } else {
        sum += (double)67.19091946977643204;
      }
    } else {
      sum += (double)-847.3040527799805659;
    }
  } else {
    if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)8.500000000000001776) ) ) {
      if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-379.409210474470342;
      } else {
        sum += (double)129.5971759959867313;
      }
    } else {
      sum += (double)729.181772362177071;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)138060.0000000000291) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13485.00000000000182) ) ) {
        sum += (double)-111.7263823349107099;
      } else {
        sum += (double)514.4546743595213911;
      }
    } else {
      sum += (double)-739.5827957984952263;
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9187.500000000001819) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1544.000000000000227) ) ) {
        sum += (double)1.588388502852865702;
      } else {
        sum += (double)312.4969512263586466;
      }
    } else {
      sum += (double)1057.721415680150358;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)9494608.000000001863) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)556.5000000000001137) ) ) {
        sum += (double)6.451930570638854334;
      } else {
        sum += (double)-328.0132329337498049;
      }
    } else {
      sum += (double)-1279.130982171835967;
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)23678519.00000000373) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-41.88051318369877407;
      } else {
        sum += (double)198.0636128333743216;
      }
    } else {
      sum += (double)1169.792465345006121;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)17635.50000000000364) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-101.9041709873954318;
      } else {
        sum += (double)106.4566483609088436;
      }
    } else {
      sum += (double)-917.5740191451956207;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)451.5000000000000568) ) ) {
        sum += (double)329.3501959648507977;
      } else {
        sum += (double)-480.3082270203071857;
      }
    } else {
      sum += (double)1021.833706533983559;
    }
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)100.5000000000000142) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15529228.50000000186) ) ) {
        sum += (double)36.93054274287766958;
      } else {
        sum += (double)-242.061657948627186;
      }
    } else {
      sum += (double)1097.226274955158715;
    }
  } else {
    sum += (double)-548.9088222250820763;
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-42.17494873369219732;
      } else {
        sum += (double)146.0710877454601757;
      }
    } else {
      sum += (double)-649.2411149139460349;
    }
  } else {
    sum += (double)662.3305797723207888;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
        sum += (double)-0.01477074232515187061;
      } else {
        sum += (double)-770.7103081136209539;
      }
    } else {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)99046.50000000001455) ) ) {
        sum += (double)82.61892131894367708;
      } else {
        sum += (double)1603.353944750497703;
      }
    }
  } else {
    sum += (double)-515.4649328014218099;
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)25367895.00000000373) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-95.83645354409749473;
      } else {
        sum += (double)109.2707370570766585;
      }
    } else {
      sum += (double)-780.4232803251567248;
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)109182.5000000000146) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1959.500000000000227) ) ) {
        sum += (double)277.3869385149533286;
      } else {
        sum += (double)-419.339869538433959;
      }
    } else {
      sum += (double)1223.813347576842943;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)15949.00000000000182) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15336.00000000000182) ) ) {
        sum += (double)-117.0707566094078658;
      } else {
        sum += (double)408.1095132742659075;
      }
    } else {
      if ( UNLIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)11665.50000000000182) ) ) {
        sum += (double)-289.8123570252528225;
      } else {
        sum += (double)-946.3926393656573737;
      }
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9805.000000000001819) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1987.500000000000227) ) ) {
        sum += (double)66.67895741435076218;
      } else {
        sum += (double)-349.2755925119262201;
      }
    } else {
      if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)893.0389358888339757;
      } else {
        sum += (double)82.21671532134084259;
      }
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-169.9364332710925964;
    } else {
      sum += (double)-912.3527938959512085;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21765.00000000000364) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)19438900.00000000373) ) ) {
        sum += (double)18.44402350808676871;
      } else {
        sum += (double)964.8545200448052128;
      }
    } else {
      sum += (double)-551.9143018117725887;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)5353.500000000000909) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)556.5000000000001137) ) ) {
        sum += (double)0.1256124532704051555;
      } else {
        sum += (double)-304.3470470249260416;
      }
    } else {
      sum += (double)-1136.228742579050504;
    }
  } else {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4264674.500000000931) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
        sum += (double)-54.22778674330068327;
      } else {
        sum += (double)166.3095024107432209;
      }
    } else {
      sum += (double)876.9477652586606382;
    }
  }
  if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4177940.000000000466) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)45502.50000000000728) ) ) {
        sum += (double)-89.78648382280304929;
      } else {
        sum += (double)56.36441951780161475;
      }
    } else {
      sum += (double)-645.9360872502088569;
    }
  } else {
    sum += (double)599.1355468650569946;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13086.00000000000182) ) ) {
        sum += (double)24.34662547883557338;
      } else {
        sum += (double)583.3183635039305273;
      }
    } else {
      sum += (double)817.0770870853764336;
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)8132456.000000000931) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)168.5000000000000284) ) ) {
        sum += (double)-104.1437030476361087;
      } else {
        sum += (double)642.0582090308157603;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)208.5000000000000284) ) ) {
        sum += (double)281.2863326878944008;
      } else {
        sum += (double)-897.626601735809345;
      }
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-160.1453710716957062;
    } else {
      sum += (double)-865.6821560776800197;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1977.500000000000227) ) ) {
        sum += (double)-257.0491717425655338;
      } else {
        sum += (double)35.08863662478120204;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1983.500000000000227) ) ) {
        sum += (double)109.87247519572378;
      } else {
        sum += (double)1187.836329180458506;
      }
    }
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
    sum += (double)-608.071782461195653;
  } else {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)38299184.00000000745) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15529228.50000000186) ) ) {
        sum += (double)47.38790720982582627;
      } else {
        sum += (double)-199.3927641260803512;
      }
    } else {
      sum += (double)641.9318041212783328;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)9494608.000000001863) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1960.500000000000227) ) ) {
        sum += (double)-335.617787410637618;
      } else {
        sum += (double)-17.36160967457871251;
      }
    } else {
      sum += (double)-1079.076441172087243;
    }
  } else {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)23678519.00000000373) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-36.06311065535556537;
      } else {
        sum += (double)164.8797534002700615;
      }
    } else {
      sum += (double)1053.002444628837338;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)9494608.000000001863) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1965.500000000000227) ) ) {
        sum += (double)-282.4294054973478865;
      } else {
        sum += (double)98.60730247089541933;
      }
    } else {
      sum += (double)-1020.37330894809395;
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)16280571.00000000186) ) ) {
        sum += (double)61.04263445210757055;
      } else {
        sum += (double)-205.1502882883803522;
      }
    } else {
      sum += (double)1010.109307225505518;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)25047.50000000000364) ) ) {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)13885841.00000000186) ) ) {
        sum += (double)7.335139342125756023;
      } else {
        sum += (double)-344.0462071867329996;
      }
    } else {
      sum += (double)1010.157308675588524;
    }
  } else {
    sum += (double)-571.920166931636345;
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1736.500000000000227) ) ) {
      sum += (double)-199.8973400346770291;
    } else {
      sum += (double)-728.8373174508382135;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2650.000000000000455) ) ) {
        sum += (double)10.36027766920140181;
      } else {
        sum += (double)1209.464629584763316;
      }
    } else {
      sum += (double)-676.3764984846308153;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)13509.00000000000182) ) ) {
      if ( UNLIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)35067.50000000000728) ) ) {
        sum += (double)-417.4299280804937666;
      } else {
        sum += (double)-45.50871181363203988;
      }
    } else {
      sum += (double)-945.8965043730964908;
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-45.6969945879273638;
      } else {
        sum += (double)175.2623311113323723;
      }
    } else {
      sum += (double)958.908705990658973;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)15949.00000000000182) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)-66.50799107839009139;
      } else {
        sum += (double)352.2240754603481037;
      }
    } else {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)436.5000000000000568) ) ) {
        sum += (double)85.45469578721555592;
      } else {
        sum += (double)-1222.372776958101213;
      }
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)96513.00000000001455) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)51895.00000000000728) ) ) {
        sum += (double)-26.69226559405545274;
      } else {
        sum += (double)204.2377152124125814;
      }
    } else {
      sum += (double)727.1730381376499963;
    }
  }
  if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)856.5000000000001137) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)817.0000000000001137) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)20356046.00000000373) ) ) {
        sum += (double)15.94028067917991009;
      } else {
        sum += (double)-382.7997128131595446;
      }
    } else {
      sum += (double)1066.234296416554798;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)888.5000000000001137) ) ) {
      sum += (double)-875.6721165117129431;
    } else {
      sum += (double)366.0521510458680723;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)5353.500000000000909) ) ) {
      if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)147.7879757215702057;
      } else {
        sum += (double)-269.5336434330777138;
      }
    } else {
      sum += (double)-933.1162817623162482;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3528661.500000000466) ) ) {
        sum += (double)31.99575493592994846;
      } else {
        sum += (double)-891.4567738182637413;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)2738936.500000000466) ) ) {
        sum += (double)-19.90009733488126642;
      } else {
        sum += (double)1523.614996147079637;
      }
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)328.5000000000000568) ) ) {
      if ( LIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)2.500000000000000444) ) ) {
        sum += (double)35.71939692031165947;
      } else {
        sum += (double)754.8910877518802636;
      }
    } else {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2149979.000000000466) ) ) {
        sum += (double)-112.5655567684909784;
      } else {
        sum += (double)-924.234678083658082;
      }
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)96513.00000000001455) ) ) {
      if ( UNLIKELY( !(data[12].missing != -1) || (data[12].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-337.0821797355693548;
      } else {
        sum += (double)95.73991954718508168;
      }
    } else {
      sum += (double)707.2754853122224858;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3528661.500000000466) ) ) {
        sum += (double)-3.476043707729379317;
      } else {
        sum += (double)-787.7351113125391748;
      }
    } else {
      sum += (double)556.9737068134897982;
    }
  } else {
    sum += (double)594.023830406410525;
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15662.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3058747.000000000466) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)10539.00000000000182) ) ) {
        sum += (double)-60.51115807945637215;
      } else {
        sum += (double)149.9972909792414271;
      }
    } else {
      sum += (double)-964.3484295754039977;
    }
  } else {
    if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)4.500000000000000888) ) ) {
      sum += (double)838.974421027149674;
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3930850.000000000466) ) ) {
        sum += (double)358.5060565893691091;
      } else {
        sum += (double)-673.9266282363549863;
      }
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15662.00000000000182) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2095.500000000000455) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)13232.00000000000182) ) ) {
        sum += (double)-38.5870225105668041;
      } else {
        sum += (double)367.6369873567550712;
      }
    } else {
      sum += (double)-709.9002561580919064;
    }
  } else {
    if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)646.5000000000001137) ) ) {
      sum += (double)763.487481148246161;
    } else {
      if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)7.500000000000000888) ) ) {
        sum += (double)397.4615888504924328;
      } else {
        sum += (double)-862.5033669110849814;
      }
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1736.500000000000227) ) ) {
      sum += (double)-179.7425923175892137;
    } else {
      sum += (double)-700.5030658688297081;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2650.000000000000455) ) ) {
        sum += (double)11.05480835275381146;
      } else {
        sum += (double)1073.747566423955504;
      }
    } else {
      sum += (double)-627.5932998655943038;
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-116.0759498456143461;
    } else {
      sum += (double)-748.9880295426336261;
    }
  } else {
    if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)13445.00000000000182) ) ) {
        sum += (double)-80.82827688411667566;
      } else {
        sum += (double)-1060.08694315282537;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4264674.500000000931) ) ) {
        sum += (double)36.8155575827463224;
      } else {
        sum += (double)861.1129559328895766;
      }
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13485.00000000000182) ) ) {
        sum += (double)-31.19785654627830951;
      } else {
        sum += (double)425.7005508684792972;
      }
    } else {
      sum += (double)-685.1575481414087108;
    }
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)22240035.00000000373) ) ) {
      if ( UNLIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
        sum += (double)-53.34524772958600636;
      } else {
        sum += (double)511.7733219719178237;
      }
    } else {
      sum += (double)1008.228442844623146;
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-108.0640605475706764;
    } else {
      sum += (double)-708.641921167952205;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16668.00000000000364) ) ) {
        sum += (double)9.393998537969999063;
      } else {
        sum += (double)916.0389835640122556;
      }
    } else {
      sum += (double)-585.1109306165063799;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2902009.500000000466) ) ) {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2389380.000000000466) ) ) {
        sum += (double)-70.89107790135702203;
      } else {
        sum += (double)551.2564038088775078;
      }
    } else {
      sum += (double)-730.6569809355000871;
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9187.500000000001819) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)5441.000000000000909) ) ) {
        sum += (double)-9.249624590480880926;
      } else {
        sum += (double)214.3828720899033442;
      }
    } else {
      sum += (double)857.7367664751602661;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-85.93560828610395674;
      } else {
        sum += (double)67.21831971500105851;
      }
    } else {
      sum += (double)-657.8227857040667459;
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1977.500000000000227) ) ) {
      sum += (double)161.0860572474290109;
    } else {
      sum += (double)848.3137725043013688;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)20713414.00000000373) ) ) {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)7438.500000000000909) ) ) {
        sum += (double)48.9400265183160883;
      } else {
        sum += (double)739.6652985088516061;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)35.50000000000000711) ) ) {
        sum += (double)-999.2291244632177722;
      } else {
        sum += (double)149.7711164617521149;
      }
    }
  } else {
    if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2008.500000000000227) ) ) {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-669.4318651357200451;
      } else {
        sum += (double)-60.170207512262607;
      }
    } else {
      sum += (double)471.9692561705470553;
    }
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)25047.50000000000364) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16668.00000000000364) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)124.5000000000000142) ) ) {
        sum += (double)-41.30771102443548415;
      } else {
        sum += (double)259.6520510355574061;
      }
    } else {
      sum += (double)811.1562200961935787;
    }
  } else {
    sum += (double)-518.3879025264873235;
  }
  if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)110.5000000000000142) ) ) {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)93.50000000000001421) ) ) {
        sum += (double)2.997800259114490107;
      } else {
        sum += (double)-727.9102159077267515;
      }
    } else {
      if ( UNLIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)671.5000000000001137) ) ) {
        sum += (double)-129.4444652753537923;
      } else {
        sum += (double)1460.443760876455826;
      }
    }
  } else {
    sum += (double)-408.3873563474797379;
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)241.5000000000000284) ) ) {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
        sum += (double)-31.57407935364277662;
      } else {
        sum += (double)870.9684414857973707;
      }
    } else {
      sum += (double)-591.9416047625284136;
    }
  } else {
    sum += (double)643.2865648387474948;
  }
  return sum;
}
