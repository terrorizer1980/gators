#include "header.h"
double predict_margin_unit3(union Entry* data) {
  double sum = (double)0;
  unsigned int tmp;
  int nid, cond, fid;  /* used for folded subtrees */
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21765.00000000000364) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16668.00000000000364) ) ) {
        sum += (double)-24.39779595648833421;
      } else {
        sum += (double)795.4205303719730864;
      }
    } else {
      sum += (double)-634.2202939995700035;
    }
  } else {
    sum += (double)608.2909469013568469;
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)-50.60919035592830539;
      } else {
        sum += (double)165.1599079208008618;
      }
    } else {
      sum += (double)-658.0980846052212883;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)568.0000000000001137) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)13424348.00000000186) ) ) {
        sum += (double)20.26925492704626919;
      } else {
        sum += (double)379.5844826968421444;
      }
    } else {
      sum += (double)898.5991799129668607;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)16924963.00000000373) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)124.5000000000000142) ) ) {
        sum += (double)-28.92614234866681144;
      } else {
        sum += (double)213.9462907443675874;
      }
    } else {
      sum += (double)-667.6806470098848649;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)12235.00000000000182) ) ) {
        sum += (double)161.7105816111758543;
      } else {
        sum += (double)-538.3779565382566261;
      }
    } else {
      sum += (double)821.3865004763778188;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15529228.50000000186) ) ) {
      if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1319.500000000000227) ) ) {
        sum += (double)-88.38296089306295755;
      } else {
        sum += (double)137.8813218465289197;
      }
    } else {
      if ( UNLIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)23.00000000000000355) ) ) {
        sum += (double)32.27045376468645799;
      } else {
        sum += (double)-301.3663895544509046;
      }
    }
  } else {
    sum += (double)524.6892255857314922;
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16164.00000000000182) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)13728.00000000000182) ) ) {
        sum += (double)-74.57231087286380955;
      } else {
        sum += (double)906.7356043418931222;
      }
    } else {
      sum += (double)-564.6543422699420489;
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)9187.500000000001819) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1987.500000000000227) ) ) {
        sum += (double)116.7600186046787769;
      } else {
        sum += (double)-294.6677903580595625;
      }
    } else {
      sum += (double)806.5213791973712887;
    }
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-103.3500202135265909;
    } else {
      sum += (double)-700.9670739254098635;
    }
  } else {
    if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)328.5000000000000568) ) ) {
        sum += (double)119.1347209202768909;
      } else {
        sum += (double)-140.3205007342518229;
      }
    } else {
      if ( LIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1983.500000000000227) ) ) {
        sum += (double)83.96721038780697199;
      } else {
        sum += (double)1031.885459757182616;
      }
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1329480.000000000233) ) ) {
        sum += (double)-114.0044355149353805;
      } else {
        sum += (double)-834.2942552610743405;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
        sum += (double)14.63322430015258568;
      } else {
        sum += (double)-414.888350394435804;
      }
    }
  } else {
    sum += (double)546.0079150932347147;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
      if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)8.500000000000001776) ) ) {
        sum += (double)103.2056966520318753;
      } else {
        sum += (double)-236.603294543625168;
      }
    } else {
      sum += (double)741.9055126723001194;
    }
  } else {
    if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)107.5000000000000142) ) ) {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)-91.74901902633170891;
      } else {
        sum += (double)821.6099720656167165;
      }
    } else {
      sum += (double)-556.1384928144473179;
    }
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
    sum += (double)-510.815163513918435;
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)37028591.00000000745) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3333237.000000000466) ) ) {
        sum += (double)12.82497263106754737;
      } else {
        sum += (double)-397.3753325552614228;
      }
    } else {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)65.50000000000001421) ) ) {
        sum += (double)795.1603664702726064;
      } else {
        sum += (double)-111.0148328960215309;
      }
    }
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
      if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1935.500000000000227) ) ) {
        sum += (double)-408.6885058067992418;
      } else {
        sum += (double)78.44058723110927644;
      }
    } else {
      sum += (double)700.8472253417750153;
    }
  } else {
    if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)313.5000000000000568) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)11974928.50000000186) ) ) {
        sum += (double)-57.80473776392555862;
      } else {
        sum += (double)-804.9351014399375117;
      }
    } else {
      sum += (double)374.8585607402982873;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15662.00000000000182) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3058747.000000000466) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)950.0000000000001137) ) ) {
        sum += (double)26.17280896755622521;
      } else {
        sum += (double)-189.6116028282075376;
      }
    } else {
      sum += (double)-867.4181195359102503;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)971.0000000000001137) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)356.5000000000000568) ) ) {
        sum += (double)695.8169365143637606;
      } else {
        sum += (double)-536.2666258471665515;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3416831.000000000466) ) ) {
        sum += (double)230.8343611266460016;
      } else {
        sum += (double)1052.618333195123796;
      }
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1533056.000000000233) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)186.5000000000000284) ) ) {
        sum += (double)171.2034244301940191;
      } else {
        sum += (double)-170.4508157359215375;
      }
    } else {
      sum += (double)-834.5551717284591859;
    }
  } else {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)36325957.50000000745) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15707520.00000000186) ) ) {
        sum += (double)54.56756361461097526;
      } else {
        sum += (double)-181.2812856446709873;
      }
    } else {
      sum += (double)856.2513788778510389;
    }
  }
  if ( UNLIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)770.5000000000001137) ) ) {
    sum += (double)-479.9444479258630167;
  } else {
    if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
        sum += (double)53.56251796627094564;
      } else {
        sum += (double)662.1303573997041667;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4093495.500000000466) ) ) {
        sum += (double)-41.05779030368484683;
      } else {
        sum += (double)-484.7216834675644463;
      }
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)25367895.00000000373) ) ) {
      if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-64.12668392386255789;
      } else {
        sum += (double)81.0460592611558468;
      }
    } else {
      sum += (double)-650.388654591412319;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1967.500000000000227) ) ) {
        sum += (double)199.1100011888760548;
      } else {
        sum += (double)-578.6220773130078214;
      }
    } else {
      sum += (double)777.8126412322857277;
    }
  }
  if ( LIKELY( !(data[10].missing != -1) || (data[10].fvalue <= (double)1.500000000000000222) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)16924963.00000000373) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)124.5000000000000142) ) ) {
        sum += (double)-27.25966637179643115;
      } else {
        sum += (double)207.6118782920225669;
      }
    } else {
      sum += (double)-588.2808497718561966;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)49.50000000000000711) ) ) {
      if ( UNLIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)6161192.000000000931) ) ) {
        sum += (double)220.5774623197794426;
      } else {
        sum += (double)-372.5644978317060918;
      }
    } else {
      sum += (double)735.4986500830189016;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2004.500000000000227) ) ) {
      if ( UNLIKELY( !(data[19].missing != -1) || (data[19].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)-324.0892538428313969;
      } else {
        sum += (double)-11.42723512296783994;
      }
    } else {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1853.500000000000227) ) ) {
        sum += (double)14.30182678588510115;
      } else {
        sum += (double)477.443121680509762;
      }
    }
  } else {
    sum += (double)483.8755611916425892;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)1533056.000000000233) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)186.5000000000000284) ) ) {
        sum += (double)164.008392106383468;
      } else {
        sum += (double)-162.3517050792207499;
      }
    } else {
      sum += (double)-785.0939345960970286;
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16668.00000000000364) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3333237.000000000466) ) ) {
        sum += (double)27.94099148498819574;
      } else {
        sum += (double)-378.4913159841237302;
      }
    } else {
      sum += (double)824.8212031685989132;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)193.5000000000000284) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)328.5000000000000568) ) ) {
        sum += (double)133.5376369120596109;
      } else {
        sum += (double)-115.4045203381610918;
      }
    } else {
      sum += (double)-626.0264968230126215;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)793.5000000000001137) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)556.5000000000001137) ) ) {
        sum += (double)98.34522769574881806;
      } else {
        sum += (double)-195.5288226319364355;
      }
    } else {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)527.5000000000001137) ) ) {
        sum += (double)212.428540889717226;
      } else {
        sum += (double)745.8920121914977699;
      }
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)15707520.00000000186) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)81774.00000000001455) ) ) {
        sum += (double)-5.751822568578916162;
      } else {
        sum += (double)401.646751944342725;
      }
    } else {
      if ( UNLIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)26.50000000000000355) ) ) {
        sum += (double)-471.2272545361428797;
      } else {
        sum += (double)-30.08348566837814175;
      }
    }
  } else {
    sum += (double)509.3981385393361165;
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)8984.000000000001819) ) ) {
      sum += (double)-504.0600560413639641;
    } else {
      sum += (double)-134.0167288635122702;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21765.00000000000364) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)19438900.00000000373) ) ) {
        sum += (double)10.69209018212043283;
      } else {
        sum += (double)806.9421442858922546;
      }
    } else {
      sum += (double)-455.417152232927549;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)21765.00000000000364) ) ) {
      if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)4047416.000000000466) ) ) {
        sum += (double)-12.71903877597038779;
      } else {
        sum += (double)181.9147109572021748;
      }
    } else {
      sum += (double)-495.4118875906438006;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)145.0000000000000284) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1347.500000000000227) ) ) {
        sum += (double)-82.11840312337406544;
      } else {
        sum += (double)-580.8200631575500665;
      }
    } else {
      sum += (double)284.0346415548943355;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-46.24927712448141648;
      } else {
        sum += (double)118.6634319883857813;
      }
    } else {
      sum += (double)-568.3409733710523142;
    }
  } else {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)547.0000000000001137) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)484.5000000000000568) ) ) {
        sum += (double)-15.20330492502768216;
      } else {
        sum += (double)268.9162192189999132;
      }
    } else {
      sum += (double)762.8124373868899966;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9924.000000000001819) ) ) {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)83134.50000000001455) ) ) {
      if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)9.500000000000001776) ) ) {
        sum += (double)-12.09551903715373378;
      } else {
        sum += (double)-218.593387557568235;
      }
    } else {
      sum += (double)-400.6118107581897334;
    }
  } else {
    if ( UNLIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)8094.500000000000909) ) ) {
      if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)7248.000000000000909) ) ) {
        sum += (double)5.899040990118313843;
      } else {
        sum += (double)1382.877815534594902;
      }
    } else {
      if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)147.7762975524669855;
      } else {
        sum += (double)-117.3700678363600218;
      }
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1329480.000000000233) ) ) {
        sum += (double)-63.58312672576236935;
      } else {
        sum += (double)-771.5606762214082437;
      }
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3930850.000000000466) ) ) {
        sum += (double)13.61531756341671695;
      } else {
        sum += (double)-333.1870185050399868;
      }
    }
  } else {
    sum += (double)460.0471257020120106;
  }
  if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)20356046.00000000373) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)11325.00000000000182) ) ) {
        sum += (double)-8.067213735561079346;
      } else {
        sum += (double)354.4623192864058296;
      }
    } else {
      if ( LIKELY( !(data[0].missing != -1) || (data[0].fvalue <= (double)98.50000000000001421) ) ) {
        sum += (double)-571.8702295328859009;
      } else {
        sum += (double)252.7568918266408673;
      }
    }
  } else {
    sum += (double)408.4729298067896934;
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-40.26530357437538754;
    } else {
      sum += (double)-579.2002083295952843;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
        sum += (double)4.286448439820971679;
      } else {
        sum += (double)856.702246558528941;
      }
    } else {
      sum += (double)-492.8314002920670305;
    }
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)882.0000000000001137) ) ) {
      if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)45679150.00000000745) ) ) {
        sum += (double)-20.59549826207150147;
      } else {
        sum += (double)574.2360998637975626;
      }
    } else {
      sum += (double)-601.5780988394524229;
    }
  } else {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)22240035.00000000373) ) ) {
      if ( UNLIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
        sum += (double)-116.3498957637797702;
      } else {
        sum += (double)265.6065814792398214;
      }
    } else {
      sum += (double)722.095300437794549;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
      if ( UNLIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)1950.500000000000227) ) ) {
        sum += (double)-308.9804168963920574;
      } else {
        sum += (double)30.35618160996538606;
      }
    } else {
      sum += (double)-740.6830334563265978;
    }
  } else {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3205482.000000000466) ) ) {
        sum += (double)22.4669696525574949;
      } else {
        sum += (double)-276.3403009245484441;
      }
    } else {
      sum += (double)891.4566138515751845;
    }
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2470.500000000000455) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2295.500000000000455) ) ) {
        sum += (double)-11.47054162651025422;
      } else {
        sum += (double)468.7506564952772692;
      }
    } else {
      sum += (double)-468.4090811871832329;
    }
  } else {
    sum += (double)474.7018047290371214;
  }
  if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)475.0000000000000568) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)449.0000000000000568) ) ) {
      if ( UNLIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)5.500000000000000888) ) ) {
        sum += (double)-89.44784880956825646;
      } else {
        sum += (double)90.14863142040195498;
      }
    } else {
      sum += (double)622.1961801880185021;
    }
  } else {
    if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)16164.00000000000182) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)168.5000000000000284) ) ) {
        sum += (double)-78.0560659805189232;
      } else {
        sum += (double)612.2164272815045933;
      }
    } else {
      sum += (double)-398.4991819034514151;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)193.5000000000000284) ) ) {
      if ( UNLIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)328.5000000000000568) ) ) {
        sum += (double)114.9328897822680773;
      } else {
        sum += (double)-105.3390195637582991;
      }
    } else {
      sum += (double)-590.8036516295281899;
    }
  } else {
    if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)15549.50000000000182) ) ) {
      if ( LIKELY( !(data[26].missing != -1) || (data[26].fvalue <= (double)6019.000000000000909) ) ) {
        sum += (double)-22.72443499135123801;
      } else {
        sum += (double)222.8175198797817416;
      }
    } else {
      sum += (double)587.2056273118586205;
    }
  }
  if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)7784925.500000000931) ) ) {
    if ( UNLIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)531720.0000000001164) ) ) {
      sum += (double)-356.1594467033434626;
    } else {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1218378.000000000233) ) ) {
        sum += (double)16.10811441853751802;
      } else {
        sum += (double)-341.2788421310395961;
      }
    }
  } else {
    if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)14745270.00000000186) ) ) {
      if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1740047.500000000233) ) ) {
        sum += (double)52.36887667660678858;
      } else {
        sum += (double)402.5388664991628502;
      }
    } else {
      if ( LIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)8.500000000000001776) ) ) {
        sum += (double)25.21368220948203387;
      } else {
        sum += (double)-292.2301841636732433;
      }
    }
  }
  if ( UNLIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)3.500000000000000444) ) ) {
    sum += (double)-434.1015434074838595;
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2004.500000000000227) ) ) {
        sum += (double)-36.58282356009169689;
      } else {
        sum += (double)128.2884680771198873;
      }
    } else {
      sum += (double)437.8188278651423957;
    }
  }
  if ( LIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2008.500000000000227) ) ) {
    if ( UNLIKELY( !(data[17].missing != -1) || (data[17].fvalue <= (double)1.500000000000000222) ) ) {
      sum += (double)469.1167789201379605;
    } else {
      if ( LIKELY( !(data[24].missing != -1) || (data[24].fvalue <= (double)10297.00000000000182) ) ) {
        sum += (double)68.10801920739395143;
      } else {
        sum += (double)-976.83018284246441;
      }
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)145.0000000000000284) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1382.500000000000227) ) ) {
        sum += (double)-83.13285542185651877;
      } else {
        sum += (double)-546.2463688928863803;
      }
    } else {
      sum += (double)275.0838862101645077;
    }
  }
  if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)15662.00000000000182) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2095.500000000000455) ) ) {
      if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)13232.00000000000182) ) ) {
        sum += (double)-29.71778116620204102;
      } else {
        sum += (double)297.1100658768589824;
      }
    } else {
      sum += (double)-603.5704969455310902;
    }
  } else {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)971.0000000000001137) ) ) {
      if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2542.500000000000455) ) ) {
        sum += (double)315.4631865763220731;
      } else {
        sum += (double)-851.4153806609950834;
      }
    } else {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)341.0000000000000568) ) ) {
        sum += (double)47.54564101656887942;
      } else {
        sum += (double)1209.085767813570556;
      }
    }
  }
  if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)370.5000000000000568) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)20784563.50000000373) ) ) {
      if ( UNLIKELY( !(data[18].missing != -1) || (data[18].fvalue <= (double)2007.500000000000227) ) ) {
        sum += (double)91.95396695177197444;
      } else {
        sum += (double)-71.12997411897175937;
      }
    } else {
      sum += (double)-520.7204133882667065;
    }
  } else {
    sum += (double)353.6222087744580449;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)25047.50000000000364) ) ) {
    if ( LIKELY( !(data[27].missing != -1) || (data[27].fvalue <= (double)18479971.00000000373) ) ) {
      if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)6.500000000000000888) ) ) {
        sum += (double)-45.93576042773224088;
      } else {
        sum += (double)150.0757490014745485;
      }
    } else {
      sum += (double)648.7453755489738114;
    }
  } else {
    sum += (double)-442.8580303066751753;
  }
  if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)370.5000000000000568) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2902009.500000000466) ) ) {
      if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2398482.000000000466) ) ) {
        sum += (double)-1.660667627048069583;
      } else {
        sum += (double)507.1822971302207748;
      }
    } else {
      sum += (double)-971.024087929934808;
    }
  } else {
    sum += (double)336.3008034509063009;
  }
  if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2721.000000000000455) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)1382.500000000000227) ) ) {
      if ( LIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2006.500000000000227) ) ) {
        sum += (double)-11.63738464632231739;
      } else {
        sum += (double)352.3901369018878995;
      }
    } else {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-595.6355309384638304;
      } else {
        sum += (double)-86.36215332383473253;
      }
    }
  } else {
    sum += (double)461.1347823704158486;
  }
  if ( UNLIKELY( !(data[4].missing != -1) || (data[4].fvalue <= (double)1914.500000000000227) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)1463270.000000000233) ) ) {
      sum += (double)-38.20381974053182716;
    } else {
      sum += (double)-575.3010384104344439;
    }
  } else {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)234.5000000000000284) ) ) {
      if ( LIKELY( !(data[9].missing != -1) || (data[9].fvalue <= (double)9.500000000000001776) ) ) {
        sum += (double)0.1486993627237103155;
      } else {
        sum += (double)562.1088310640700456;
      }
    } else {
      sum += (double)-460.6757179589692441;
    }
  }
  if ( LIKELY( !(data[3].missing != -1) || (data[3].fvalue <= (double)5.500000000000000888) ) ) {
    if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)193.5000000000000284) ) ) {
      if ( LIKELY( !(data[6].missing != -1) || (data[6].fvalue <= (double)355.5000000000000568) ) ) {
        sum += (double)-70.15079988830271418;
      } else {
        sum += (double)279.772851415398236;
      }
    } else {
      sum += (double)-542.5019162873422829;
    }
  } else {
    if ( LIKELY( !(data[20].missing != -1) || (data[20].fvalue <= (double)9805.000000000001819) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)1.00000001800250948e-35) ) ) {
        sum += (double)46.70420251459132999;
      } else {
        sum += (double)-143.2909768991299302;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)763.0000000000001137) ) ) {
        sum += (double)172.0268087756996636;
      } else {
        sum += (double)769.9591187593163113;
      }
    }
  }
  if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)38299184.00000000745) ) ) {
    if ( LIKELY( !(data[21].missing != -1) || (data[21].fvalue <= (double)2795716.000000000466) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)168.5000000000000284) ) ) {
        sum += (double)-13.07895314104362328;
      } else {
        sum += (double)295.7391552222181872;
      }
    } else {
      sum += (double)-600.2922811251969506;
    }
  } else {
    sum += (double)403.2828069670974287;
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)191.0000000000000284) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)3983150.000000000466) ) ) {
      if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
        sum += (double)-32.87342551573704696;
      } else {
        sum += (double)101.2618008202695563;
      }
    } else {
      sum += (double)-432.0548379354654571;
    }
  } else {
    sum += (double)395.0223911594964079;
  }
  if ( LIKELY( !(data[16].missing != -1) || (data[16].fvalue <= (double)141.0000000000000284) ) ) {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)2542.500000000000455) ) ) {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)928.5000000000001137) ) ) {
        sum += (double)30.88952035026452236;
      } else {
        sum += (double)-167.9524848681133165;
      }
    } else {
      sum += (double)-410.0863432350691937;
    }
  } else {
    if ( LIKELY( !(data[8].missing != -1) || (data[8].fvalue <= (double)1923.000000000000227) ) ) {
      if ( UNLIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)14995110.00000000186) ) ) {
        sum += (double)207.9016262767932801;
      } else {
        sum += (double)-75.37394241735724165;
      }
    } else {
      sum += (double)722.2633311176377902;
    }
  }
  if ( LIKELY( !(data[14].missing != -1) || (data[14].fvalue <= (double)370.5000000000000568) ) ) {
    if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)30223721.50000000373) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)106275.0000000000146) ) ) {
        sum += (double)-11.78523143128826867;
      } else {
        sum += (double)285.3814296496526026;
      }
    } else {
      sum += (double)-581.3061431413194668;
    }
  } else {
    sum += (double)311.7846922719620011;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)25047.50000000000364) ) ) {
    if ( LIKELY( !(data[22].missing != -1) || (data[22].fvalue <= (double)37028591.00000000745) ) ) {
      if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)121383.0000000000146) ) ) {
        sum += (double)2.021466076566220682;
      } else {
        sum += (double)-495.5604209523698955;
      }
    } else {
      sum += (double)633.8112365480186554;
    }
  } else {
    sum += (double)-421.0163991539579911;
  }
  if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)38299184.00000000745) ) ) {
    if ( LIKELY( !(data[23].missing != -1) || (data[23].fvalue <= (double)4093495.500000000466) ) ) {
      if ( LIKELY( !(data[29].missing != -1) || (data[29].fvalue <= (double)12607330.00000000186) ) ) {
        sum += (double)35.93929161640826209;
      } else {
        sum += (double)-76.63063775699851021;
      }
    } else {
      sum += (double)-581.8941450262972239;
    }
  } else {
    sum += (double)408.2779088115677837;
  }
  if ( LIKELY( !(data[1].missing != -1) || (data[1].fvalue <= (double)25047.50000000000364) ) ) {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
      if ( LIKELY( !(data[15].missing != -1) || (data[15].fvalue <= (double)124.5000000000000142) ) ) {
        sum += (double)-32.78922165947767553;
      } else {
        sum += (double)178.7661742677866243;
      }
    } else {
      sum += (double)809.1392378292603098;
    }
  } else {
    sum += (double)-409.4813863528468687;
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[5].missing != -1) || (data[5].fvalue <= (double)2003.500000000000227) ) ) {
      if ( LIKELY( !(data[13].missing != -1) || (data[13].fvalue <= (double)602.5000000000001137) ) ) {
        sum += (double)-146.1436882737187375;
      } else {
        sum += (double)342.1510973895408938;
      }
    } else {
      sum += (double)-689.993039369482176;
    }
  } else {
    if ( LIKELY( !(data[28].missing != -1) || (data[28].fvalue <= (double)2592594.000000000466) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1950.500000000000227) ) ) {
        sum += (double)165.2310614243079669;
      } else {
        sum += (double)-27.56384737741022661;
      }
    } else {
      sum += (double)830.8732675726813568;
    }
  }
  if ( UNLIKELY( !(data[2].missing != -1) || (data[2].fvalue <= (double)1.00000001800250948e-35) ) ) {
    if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)646.5000000000001137) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1959.500000000000227) ) ) {
        sum += (double)-217.6059065845652469;
      } else {
        sum += (double)123.0429199288845581;
      }
    } else {
      if ( LIKELY( !(data[7].missing != -1) || (data[7].fvalue <= (double)913.0000000000001137) ) ) {
        sum += (double)-796.6316314752928065;
      } else {
        sum += (double)57.60824535970196791;
      }
    }
  } else {
    if ( LIKELY( !(data[25].missing != -1) || (data[25].fvalue <= (double)150567.0000000000291) ) ) {
      if ( UNLIKELY( !(data[11].missing != -1) || (data[11].fvalue <= (double)1950.500000000000227) ) ) {
        sum += (double)158.6499915951067408;
      } else {
        sum += (double)-25.66447891068765585;
      }
    } else {
      sum += (double)772.9108651684899769;
    }
  }
  return sum;
}
